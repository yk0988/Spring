package com.company.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MemberDTO {

    private Long studentId;  
    
    private String studentName; 
    private int kScore;  
    private int eScore; 
    private int mScore;  
}
