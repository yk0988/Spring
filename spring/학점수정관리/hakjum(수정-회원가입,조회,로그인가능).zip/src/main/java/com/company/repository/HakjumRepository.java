package com.company.repository;


import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Repository;

import com.company.dto.HakjumDTO;

import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class HakjumRepository {
	
	
  private final SqlSessionTemplate sql;

	
	public List<HakjumDTO> findAll() {
    return sql.selectList("Hakjum.findAll");
	}
	
	public int save(HakjumDTO hakjumDTO) {
        return sql.insert("Hakjum.save", hakjumDTO); 
    }

	public void delete(Long id) {
		 sql.delete("Hakjum.delete", id);
	}

	
	public HakjumDTO findBystudentId(Long studentId) {
	    return sql.selectOne("Hakjum.findBystudentId", studentId);
	}


	public int update(HakjumDTO hakjumDTO) {
		 return sql.update("Hakjum.update", hakjumDTO);
	}

	public HakjumDTO login(HakjumDTO hakjumDTO) {
		 return sql.selectOne("Hakjum.login", hakjumDTO);
	}
	

}