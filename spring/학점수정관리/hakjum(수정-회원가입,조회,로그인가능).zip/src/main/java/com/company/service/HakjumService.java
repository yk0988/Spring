package com.company.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.company.dto.HakjumDTO;
import com.company.repository.HakjumRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class HakjumService {

	private final HakjumRepository hakjumRepository;

	/*
	 * public int save(hakjumDTO hakjumDTO) { return
	 * hakjumRepository.save(hakjumDTO); }
	 * 
	 * public boolean login(hakjumDTO hakjumDTO) { hakjumDTO loginMember =
	 * hakjumRepository.login(hakjumDTO); if(loginMember != null){ return true;
	 * }else{ return false; } }
	*/
	 public HakjumDTO findBystudentId(Long id) 
	 { return hakjumRepository.findBystudentId(id); }
	 
	public List<HakjumDTO> findAll() {
		return hakjumRepository.findAll();
	}
	
	public void delete(Long id) { hakjumRepository.delete(id);
	}

	 public boolean save(HakjumDTO hakjumDTO) {
		 try {
			 hakjumRepository.save(hakjumDTO);
			 return true;
		 } catch (Exception e) {
			return false; 
		 }
	  }
	 public boolean modify(HakjumDTO hakjumDTO) {
		 try {
			 hakjumRepository.update(hakjumDTO);
			 return true;
		 } catch (Exception e) {
			return false; 
		 }
	  }

		public boolean login(HakjumDTO hakjumDTO) {
			  HakjumDTO loginHakjum = hakjumRepository.login(hakjumDTO);
			    if(loginHakjum != null){
			      return true;
			    }else{
			      return false;
			    }
		}

	

	
	/*
	 * public void delete(Long id) { hakjumRepository.delete(id);
	 * 
	 * }
	 * 
	 * public hakjumDTO findByStudentId(String StudentId) { return
	 * hakjumRepository.findBystudentId(StudentId); }
	 * 
	 * public boolean update(hakjumDTO hakjumDTO) { int result =
	 * hakjumRepository.update(hakjumDTO); if (result > 0) { return true; } else {
	 * return false; } }
	 * 
	 * public String emailCheck(String studentId) { hakjumDTO memberDTO =
	 * hakjumRepository.findBystudentId(studentId); if (memberDTO == null) { return
	 * "ok"; } else { return "no"; }
	 * 
	 * }
	 */

}